const jwt = require('jsonwebtoken');
const COOKIE = 'sahayak_token';

function setCookie(res, id) {
  const token = jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.cookie(COOKIE, token, {
    httpOnly: true, sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 7 * 24 * 3600 * 1000
  });
}
function readUser(req) {
  try { return jwt.verify(req.cookies[COOKIE], process.env.JWT_SECRET); } catch (e) { return null; }
}
function requireAuth(req, res, next) {
  const u = readUser(req);
  if (!u) return res.status(401).json({ error: 'Please sign in', code: 'auth' });
  req.userId = u.id;
  next();
}
function pageGuard(req, res, next) { readUser(req) ? next() : res.redirect('/login'); }

module.exports = { COOKIE, setCookie, readUser, requireAuth, pageGuard };
