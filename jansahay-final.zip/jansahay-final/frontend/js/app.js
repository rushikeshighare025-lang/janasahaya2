/* JanSahay - app logic: rendering, search/filters, theme. Data comes from the backend API (profile, schemes, matches, vault, reminders). */
function T(k){return UI[k][lang]}
function $(i){return document.getElementById(i)}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function sc(id){return S.filter(function(s){return s[0]==id})[0]}
function matches(){return S.map(function(s){return{s:s,v:LV[s[0]]||0}}).filter(function(m){return m.v>0}).sort(function(a,b){return b.v-a.v})}
function have(d){return vault.some(function(f){return f.type==d})}
function days(d){return Math.round((new Date(d+'T00:00:00')-new Date(new Date().toDateString()))/864e5)}
function plus(n){var d=new Date(Date.now()+n*864e5);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
function opts(a,v,c){return a.map(function(x,i){return'<option value="'+v[i]+'"'+(v[i]==c?' selected':'')+'>'+esc(x)+'</option>'}).join('')}
function reload(){return api('/me/documents').then(function(v){vault=v;vaultErr=0}).catch(function(){vaultErr=1})}
function fileUrl(f){return '/api/me/documents/'+f.id+'/file'}
function view(){
 head();var h='';
 if(tab==0){h=profileHTML()}
 if(tab==1){
  h+='<section class="hero"><h2>'+T('hero')+'</h2><p>'+T('heros')+'</p><div class="srch"><input id="q" type="search" value="'+esc(q)+'" placeholder="'+esc(T('ph'))+'" aria-label="'+esc(T('ph'))+'"><select id="hstate" aria-label="'+T('state')+'">'+opts(STATES,STATES,p.state)+'</select></div><button class="cta" data-go="0">'+(saved?T('edit'):T('chk2'))+'</button></section>';
  h+='<div class="cats" role="group">'+['all'].concat(Object.keys(UI.cats)).map(function(c){return'<button class="cat" data-c="'+c+'" aria-pressed="'+(cf==c)+'">'+(c=='all'?T('all'):UI.cats[c][lang])+'</button>'}).join('')+'</div>';
  if(flash)h+='<div class="msg g" role="status">'+flash+'</div>';
  if(!saved)h+='<div class="msg w">'+T('cp')+'</div>';
  else h+='<label class="om"><input type="checkbox" id="om"'+(om?' checked':'')+'>'+T('om')+'</label>';
  h+='<div id="res">'+resHTML()+'</div>'}
 if(tab==2){
  h='<div class="panel"><p style="margin-top:0" class="mute">'+T('vi')+'</p>'+(flash?'<div class="msg b" role="alert">'+flash+'</div>':'')+(vaultErr?'<div class="msg b">'+T('verr')+'</div>':'');
  h+=Object.keys(D).map(function(d){var fs=vault.filter(function(f){return f.type==d});
   return'<div class="vrow"><div><b>'+D[d][lang]+'</b><div class="files">'+fs.map(function(f){return'<div class="file">📄 '+esc(f.name)+' ('+Math.max(1,Math.round(f.size/1024))+' KB) <a class="ghost" href="'+fileUrl(f)+'" target="_blank" rel="noopener" download="'+esc(f.name)+'">'+T('open')+'</a><button class="ghost" data-df="'+f.id+'">'+T('del')+'</button></div>'}).join('')+'</div></div>'+
   '<span class="ghost up">'+T('up')+'<input type="file" aria-label="'+T('up')+' '+esc(D[d][lang])+'" accept=".pdf,.jpg,.jpeg,.png" multiple data-up="'+d+'"></span></div>'}).join('')+'</div>'}
 if(tab==3){
  h=feed.map(function(id){return'<div class="n"><div>🔔 <b>'+T('newm')+'</b> '+sc(id)[3][lang]+'</div><button class="ghost" data-fd="'+id+'">'+T('del')+'</button></div>'}).join('')+
  rem.slice().sort(function(a,b){return a.d<b.d?-1:1}).map(function(r){var n=days(r.d);
   return'<div class="n'+(n<=7?' w':'')+'"><div>⏰ <b>'+T('remm')+'</b> '+sc(r.id)[3][lang]+'<br><span class="mute">'+r.d+' · '+(n==0?T('today'):n>0?n+' '+T('left'):(-n)+' '+T('late'))+'</span></div><button class="ghost" data-rm="'+r.k+'">'+T('del')+'</button></div>'}).join('');
  if(!h)h='<div class="panel empty">'+T('none')+'</div>'}
 $('main').innerHTML=h;flash=tab==1?null:flash}
function toRow(r){var a=[r.code,null,r.docs,[r.name,r.name_hi||r.name,r.name_mr||r.name],[r.benefits,r.benefits_hi||r.benefits,r.benefits_mr||r.benefits],r.application_url];a.st=r.state;a.hide=r.hide_in_state;a.cat=r.category;return a}
function saveProfile(){
 if(p.nt&&window.Notification&&Notification.permission=='default'){try{Notification.requestPermission()}catch(x){}}
 api('/me/profile',{method:'PUT',body:Object.assign({},p,{lang:lang})}).then(function(r){
  saved=true;LV=r.levels;feed=r.feed;om=true;tab=1;
  r.fresh.forEach(function(id){if(p.nt&&window.Notification&&Notification.permission=='granted'){try{new Notification('JanSahay',{body:T('newm')+' '+sc(id)[3][lang]})}catch(e){}}});
  flash=T('sd')+' '+matches().length+' '+T('sd2');view()
 }).catch(function(e){flash='⚠ '+e.message;tab=0;view()})}
document.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;var d=b.dataset;
 if(d.delacc){if(confirm(T('delc')))api('/me',{method:'DELETE'}).then(function(){location.href='/login'});return}if(d.out){api('/auth/logout',{method:'POST'}).then(function(){location.href='/login'});return}if(d.l){lang=+d.l;try{localStorage.setItem('sahayak_lang',lang)}catch(x){}}else if('c' in d)cf=d.c;else if(d.th){toggleTheme();return}else if(d.fs){setFs(d.fs);return}else if(d.go){tab=+d.go;flash=null}
 else if(d.t){tab=+d.t;flash=null}
 else if(b.id=='go'){saveProfile();return}
 else if(d.al){var v=$('d_'+d.al).value;if(!v)return;api('/me/alerts',{method:'POST',body:{code:d.al,date:v}}).then(function(x){rem.push(x);tab=3;view()}).catch(function(e){flash='⚠ '+e.message;view()});return}
 else if(d.rm){api('/me/alerts/'+d.rm,{method:'DELETE'});rem=rem.filter(function(x){return x.k!=d.rm})}
 else if(d.fd){api('/me/recommendations/'+d.fd,{method:'DELETE'});feed=feed.filter(function(x){return x!=d.fd})}
 else if(d.df){api('/me/documents/'+d.df,{method:'DELETE'}).then(reload).then(view);return}
 else return;view()});
document.addEventListener('change',function(e){var t=e.target,d=t.dataset;
 if(t.id=='om'){om=t.checked;view();return}else if(t.id=='hstate'){p.state=t.value;sv();view();return}else if(d.k)p[d.k]=t.checked?1:0;
 else if(t.id=='nt')p.nt=t.checked?1:0;
 else if(d.up){var fs=Array.prototype.slice.call(t.files),bad=0,ok=fs.filter(function(f){var g=/\.(pdf|jpe?g|png)$/i.test(f.name)&&f.size<=4194304;if(!g)bad=1;return g});
  flash=bad?T('big'):null;
  if(!ok.length){view();return}
  ok.reduce(function(pr,f){return pr.then(function(){var fd=new FormData();fd.append('type',d.up);fd.append('files',f);return api('/me/documents',{method:'POST',body:fd})})},Promise.resolve())   /* one request per file: hosts like Vercel cap a request at 4.5 MB */
    .catch(function(e){flash=e.message}).then(reload).then(view);return}
 else if(['age','inc','fam'].indexOf(t.id)>-1)p[t.id]=+t.value||0;
 else if(['name','mob','state','gender','occ','cat','district','edu','emp','email'].indexOf(t.id)>-1)p[t.id]=t.value;
 else return;sv();if(tab==0){var el=$('pc');if(el)el.innerHTML=pcHTML()}});
var cf='all',q='',om=saved,pref={};
try{pref=JSON.parse(localStorage.getItem('sahayak_ui'))||{}}catch(e){}
Object.assign(UI,{
hero:['Find government schemes you are eligible for','आपके लिए पात्र सरकारी योजनाएँ खोजें','तुमच्यासाठी पात्र सरकारी योजना शोधा'],
heros:['Browse central and Maharashtra schemes, check eligibility from your profile and apply on the official portal.','केंद्र और महाराष्ट्र की योजनाएँ देखें, प्रोफ़ाइल से पात्रता जाँचें और आधिकारिक पोर्टल पर आवेदन करें।','केंद्र व महाराष्ट्र योजना पहा, प्रोफाइलवरून पात्रता तपासा आणि अधिकृत पोर्टलवर अर्ज करा.'],
ph:['Search: scholarship, pension, farmer…','खोजें: छात्रवृत्ति, पेंशन, किसान…','शोधा: शिष्यवृत्ती, पेन्शन, शेतकरी…'],
chk2:['Check my eligibility','मेरी पात्रता जाँचें','माझी पात्रता तपासा'],edit:['Edit my profile','मेरी प्रोफ़ाइल बदलें','माझी प्रोफाइल बदला'],
all:['All','सभी','सर्व'],
cats:{edu:['Education','शिक्षा','शिक्षण'],agri:['Agriculture','कृषि','शेती'],health:['Health','स्वास्थ्य','आरोग्य'],women:['Women & child','महिला एवं बाल','महिला व बाल'],soc:['Social security','सामाजिक सुरक्षा','सामाजिक सुरक्षा'],house:['Housing','आवास','गृहनिर्माण'],biz:['Business & loans','व्यवसाय एवं ऋण','व्यवसाय व कर्ज']},
om:['Show only schemes that match my profile','केवल मेरी प्रोफ़ाइल से मिलती योजनाएँ','फक्त माझ्या प्रोफाइलशी जुळणाऱ्या योजना'],
cnt:['schemes found','योजनाएँ मिलीं','योजना आढळल्या'],cen:['Central','केंद्र','केंद्र'],mhs:['Maharashtra','महाराष्ट्र','महाराष्ट्र'],
nm:['Not matched to your profile','आपकी प्रोफ़ाइल से मेल नहीं','तुमच्या प्रोफाइलशी जुळत नाही'],
nr:['No schemes found. Try another word or category.','कोई योजना नहीं मिली। दूसरा शब्द या श्रेणी आज़माएँ।','योजना आढळली नाही. दुसरा शब्द किंवा प्रवर्ग वापरा.'],
cp:['Tap “Check my eligibility” to enter your details and see which schemes you qualify for.','अपनी जानकारी भरने के लिए “मेरी पात्रता जाँचें” दबाएँ।','माहिती भरण्यासाठी “माझी पात्रता तपासा” दाबा.'],
gov:['Independent helper tool, not an official government website','स्वतंत्र सहायक टूल, आधिकारिक सरकारी वेबसाइट नहीं','स्वतंत्र सहाय्यक साधन, अधिकृत सरकारी संकेतस्थळ नाही'],
dark:['Dark mode','डार्क मोड','डार्क मोड'],fsl:['Text size','अक्षर आकार','अक्षर आकार']});
function inScope(s){return(s.st=='All India'||s.st==p.state)&&s.hide!=p.state}
function resHTML(){
 var ql=q.trim().toLowerCase();
 var L=S.filter(inScope).map(function(s){return{s:s,v:saved?(LV[s[0]]||0):0}}).filter(function(x){
  if(cf!='all'&&x.s.cat!=cf)return false;
  if(saved&&om&&!x.v)return false;
  return !ql||(x.s[3].join(' ')+' '+x.s[4].join(' ')+' '+UI.cats[x.s.cat].join(' ')).toLowerCase().indexOf(ql)>-1}).sort(function(a,b){return b.v-a.v});
 var h='<p class="mute" role="status"><b>'+L.length+'</b> '+T('cnt')+'</p>'+(!mh(p)?'<div class="msg w">'+T('ns')+'</div>':'');
 if(!L.length)return h+'<div class="panel empty">'+T('nr')+'</div>';
 return h+L.map(function(x){var s=x.s,k=s[2].filter(have).length,pc=Math.round(k/s[2].length*100);
  return'<article class="sch"><div class="pills"><span class="pill lv">'+(s.st!='All India'?T('mhs'):T('cen'))+'</span><span class="pill">'+UI.cats[s.cat][lang]+'</span></div>'+
  '<div class="top"><h3>'+s[3][lang]+'</h3>'+(saved?'<span class="tag t'+x.v+'">'+(x.v==2?T('elig'):x.v==1?T('chk'):T('nm'))+'</span>':'')+'</div>'+
  '<p class="ben">'+s[4][lang]+'</p><div class="chips">'+s[2].map(function(d){return'<span class="chip '+(have(d)?'ok':'no')+'">'+(have(d)?'✓ ':'✗ ')+D[d][lang]+'</span>'}).join('')+'</div>'+
  '<div class="bar" role="progressbar" aria-valuenow="'+pc+'" aria-valuemin="0" aria-valuemax="100"><i style="width:'+pc+'%"></i></div><div class="mute">'+k+'/'+s[2].length+' '+T('ready')+'</div>'+
  '<details><summary>'+T('steps')+'</summary><p class="mute">'+T('st')+'</p></details>'+
  '<div class="row"><a class="primary" href="'+esc(s[5])+'" target="_blank" rel="noopener noreferrer">'+T('apply')+' ↗</a>'+
  '<label class="mute" style="margin:0;font-weight:500" for="d_'+s[0]+'">'+T('rm')+'</label><input type="date" id="d_'+s[0]+'" value="'+plus(30)+'"><button class="ghost" data-al="'+s[0]+'">'+T('setr')+'</button></div></article>'}).join('')}
function applyUi(){var th=pref.th||(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');document.documentElement.dataset.theme=th;document.documentElement.dataset.fs=pref.fs||'m';return th}
function saveUi(){try{localStorage.setItem('sahayak_ui',JSON.stringify(pref))}catch(e){}}
function toggleTheme(){pref.th=applyUi()=='dark'?'light':'dark';saveUi();applyUi();view()}
function setFs(v){pref.fs=v;saveUi();applyUi();view()}
function head(){
 var th=applyUi(),fs=pref.fs||'m';
 $('s').textContent=T('gov');$('note').textContent=T('note');document.documentElement.lang=['en','hi','mr'][lang];
 $('util').innerHTML='<div class="g"><span>'+T('fsl')+'</span>'+[['s','A-'],['m','A'],['l','A+']].map(function(x){return'<button class="u" data-fs="'+x[0]+'" aria-pressed="'+(fs==x[0])+'" aria-label="'+T('fsl')+' '+x[1]+'">'+x[1]+'</button>'}).join('')+'</div>'+
 '<div class="g"><span>🌙 '+T('dark')+'</span><button class="sw" data-th="1" role="switch" aria-checked="'+(th=='dark')+'" aria-label="'+T('dark')+'"><i></i></button></div>'+
 '<div class="g">'+['English','हिन्दी','मराठी'].map(function(n,i){return'<button class="u" data-l="'+i+'" aria-pressed="'+(lang==i)+'">'+n+'</button>'}).join('')+'<button class="u" data-out="1">'+T('logout')+(me?' ('+esc(me.name)+')':'')+'</button></div>';
 var c=feed.length+rem.length;
 $('nav').innerHTML=[1,0,2,3].map(function(i){return'<button role="tab" aria-selected="'+(i==tab)+'" data-t="'+i+'">'+UI.tabs[lang][i]+(i==3&&c?'<span class="badge">'+c+'</span>':'')+'</button>'}).join('')}
document.addEventListener('input',function(e){if(e.target.id=='q'){q=e.target.value;var r=$('res');if(r)r.innerHTML=resHTML()}});

/* ---------- My profile page ---------- */
Object.assign(UI,{
s1:['Personal details','व्यक्तिगत विवरण','वैयक्तिक माहिती'],s2:['Location','स्थान','ठिकाण'],s3:['Family & income','परिवार और आय','कुटुंब व उत्पन्न'],
s4:['Education & work','शिक्षा और रोज़गार','शिक्षण व रोजगार'],s5:['Category & special status','वर्ग और विशेष स्थिति','प्रवर्ग व विशेष स्थिती'],
s6:['Preferences','पसंद','प्राधान्ये'],s7:['Account','खाता','खाते'],
dist:['District','ज़िला','जिल्हा'],email:['Email (optional)','ईमेल (वैकल्पिक)','ईमेल (ऐच्छिक)'],fam:['Family members','परिवार के सदस्य','कुटुंबातील सदस्य'],
edu:['Education level','शिक्षा स्तर','शिक्षण पातळी'],emp:['Employment status','रोज़गार स्थिति','रोजगार स्थिती'],pick:['Select','चुनें','निवडा'],
eduv:[['Below 10th','10th pass','12th pass','Diploma','Graduate','Postgraduate','Other'],['10वीं से कम','10वीं पास','12वीं पास','डिप्लोमा','स्नातक','स्नातकोत्तर','अन्य'],['१० वी पेक्षा कमी','१० वी उत्तीर्ण','१२ वी उत्तीर्ण','पदविका','पदवीधर','पदव्युत्तर','इतर']],
empv:[['Unemployed','Employed','Self-employed','Student','Retired'],['बेरोज़गार','नौकरीपेशा','स्वरोज़गार','विद्यार्थी','सेवानिवृत्त'],['बेरोजगार','नोकरदार','स्वयंरोजगार','विद्यार्थी','निवृत्त']],
pcl:['Profile completeness','प्रोफ़ाइल पूर्णता','प्रोफाइल पूर्णता'],pcd:['Your profile is complete.','आपकी प्रोफ़ाइल पूरी है।','तुमची प्रोफाइल पूर्ण आहे.'],
tip:{dist:['Add your district','अपना ज़िला जोड़ें','तुमचा जिल्हा जोडा'],edu:['Choose your education level','शिक्षा स्तर चुनें','शिक्षण पातळी निवडा'],emp:['Choose your employment status','रोज़गार स्थिति चुनें','रोजगार स्थिती निवडा'],doc:['Upload your Aadhaar card in the vault','तिजोरी में आधार कार्ड अपलोड करें','तिजोरीत आधार कार्ड अपलोड करा'],save:['Save your profile to see matches','योजनाएँ देखने के लिए प्रोफ़ाइल सहेजें','जुळणाऱ्या योजना पाहण्यासाठी प्रोफाइल जतन करा']},
st1:['Schemes matched','मिली योजनाएँ','जुळलेल्या योजना'],st2:['Documents','दस्तावेज़','कागदपत्रे'],st3:['Reminders','अलर्ट','आठवणी'],
lg:['Language','भाषा','भाषा'],mobn:['Mobile number (sign-in id, cannot be changed)','मोबाइल नंबर (साइन-इन आईडी, बदला नहीं जा सकता)','मोबाईल क्रमांक (साइन-इन आयडी, बदलता येत नाही)'],
sbn:['Changes are saved when you press the button.','बटन दबाने पर बदलाव सहेजे जाते हैं।','बटण दाबल्यावर बदल जतन होतात.'],
delb:['Delete my account and files','मेरा खाता और फ़ाइलें हटाएँ','माझे खाते व फायली हटवा'],
delc:['Delete your account, profile and all uploaded documents? This cannot be undone.','अपना खाता, प्रोफ़ाइल और सभी अपलोड दस्तावेज़ हटाएँ? यह वापस नहीं हो सकता।','तुमचे खाते, प्रोफाइल व सर्व अपलोड कागदपत्रे हटवायची? हे पूर्ववत होणार नाही.']});
function fld(id,label,inner){return'<div><label for="'+id+'">'+label+'</label>'+inner+'</div>'}
function sel(id,arr,vals,cur,ph){return'<select id="'+id+'">'+(ph?'<option value=""'+(cur?'':' selected')+'>'+T('pick')+'</option>':'')+opts(arr,vals,cur)+'</select>'}
function pcItems(){return[['dist',!!p.district],['edu',!!p.edu],['emp',!!p.emp],['doc',have('aadhaar')],['save',saved]]}
function pcHTML(){
 var it=pcItems(),todo=it.filter(function(x){return!x[1]}),pc=Math.round((6+it.length-todo.length)/(6+it.length)*100);
 var ini=String(p.name||'?').trim().split(/\s+/).slice(0,2).map(function(w){return w.charAt(0).toUpperCase()}).join('')||'?';
 return'<div class="pfh"><div class="avatar" aria-hidden="true">'+esc(ini)+'</div><div class="who"><h2>'+esc(p.name||'')+'</h2><div class="mute">+91 '+esc(p.mob||'')+' · '+esc(p.state)+(p.district?', '+esc(p.district):'')+'</div></div></div>'+
 '<div style="margin-top:14px"><b>'+T('pcl')+': '+pc+'%</b><div class="bar" role="progressbar" aria-valuenow="'+pc+'" aria-valuemin="0" aria-valuemax="100"><i style="width:'+pc+'%"></i></div>'+
 (todo.length?'<ul class="tips">'+todo.map(function(x){return'<li>'+UI.tip[x[0]][lang]+'</li>'}).join('')+'</ul>':'<div class="mute">'+T('pcd')+'</div>')+'</div>'+
 '<div class="stats"><div class="stat"><b>'+matches().length+'</b>'+T('st1')+'</div><div class="stat"><b>'+vault.length+'</b>'+T('st2')+'</div><div class="stat"><b>'+rem.length+'</b>'+T('st3')+'</div></div>'}
function profileHTML(){
 var h='';
 if(flash)h+='<div class="msg g" role="status">'+flash+'</div>';
 h+='<section class="panel" id="pc">'+pcHTML()+'</section>';
 h+='<section class="panel sec"><h3><span aria-hidden="true">👤</span>'+T('s1')+'</h3><div class="grid">'+
  fld('name',T('name'),'<input id="name" type="text" maxlength="100" autocomplete="name" value="'+esc(p.name)+'">')+
  fld('age',T('age'),'<input id="age" type="number" min="0" max="120" value="'+p.age+'">')+
  fld('gender',T('gen'),sel('gender',UI.gv[lang],['m','f','o'],p.gender))+
  fld('mob',T('mobn'),'<input id="mob" type="tel" value="'+esc(p.mob)+'" readonly>')+
  fld('email',T('email'),'<input id="email" type="email" maxlength="150" autocomplete="email" value="'+esc(p.email||'')+'">')+'</div></section>';
 h+='<section class="panel sec"><h3><span aria-hidden="true">📍</span>'+T('s2')+'</h3><div class="grid">'+
  fld('state',T('state'),sel('state',STATES,STATES,p.state))+
  fld('district',T('dist'),'<input id="district" type="text" maxlength="100" value="'+esc(p.district||'')+'">')+'</div></section>';
 h+='<section class="panel sec"><h3><span aria-hidden="true">🏠</span>'+T('s3')+'</h3><div class="grid">'+
  fld('inc',T('inc'),sel('inc',UI.bands[lang],[0,1,2,3,4],p.inc))+
  fld('fam',T('fam'),'<input id="fam" type="number" min="1" max="30" value="'+esc(p.fam||'')+'">')+'</div></section>';
 h+='<section class="panel sec"><h3><span aria-hidden="true">🎓</span>'+T('s4')+'</h3><div class="grid">'+
  fld('edu',T('edu'),sel('edu',UI.eduv[lang],['below10','10','12','diploma','grad','pg','other'],p.edu,1))+
  fld('emp',T('emp'),sel('emp',UI.empv[lang],['unemployed','employed','self','student','retired'],p.emp,1))+
  fld('occ',T('occ'),sel('occ',UI.ov[lang],['farmer','student','vendor','worker','homemaker','other'],p.occ))+'</div></section>';
 h+='<section class="panel sec"><h3><span aria-hidden="true">🪪</span>'+T('s5')+'</h3><div class="grid">'+
  fld('cat',T('cat'),sel('cat',['General','OBC','SC','ST'],['General','OBC','SC','ST'],p.cat))+'</div>'+
  '<div class="checks">'+Object.keys(UI.ck).map(function(k){return'<label><input type="checkbox" data-k="'+k+'"'+(p[k]?' checked':'')+'>'+UI.ck[k][lang]+'</label>'}).join('')+'</div></section>';
 h+='<section class="panel sec"><h3><span aria-hidden="true">⚙️</span>'+T('s6')+'</h3><div class="row" style="margin:0 0 12px"><b>'+T('lg')+':</b>'+
  ['English','हिन्दी','मराठी'].map(function(n,i){return'<button class="cat" data-l="'+i+'" aria-pressed="'+(lang==i)+'">'+n+'</button>'}).join('')+'</div>'+
  '<div class="checks" style="margin:0"><label><input type="checkbox" id="nt"'+(p.nt?' checked':'')+'>'+T('nt')+'</label></div></section>';
 h+='<section class="panel sec"><h3><span aria-hidden="true">🔐</span>'+T('s7')+'</h3><div class="row" style="margin:0"><button class="ghost" data-out="1">'+T('logout')+'</button><button class="ghost danger" data-delacc="1">'+T('delb')+'</button></div></section>';
 h+='<div class="savebar"><span class="mute">'+T('sbn')+'</span><button class="primary" id="go">'+T('save')+'</button></div>';
 return h}
Object.assign(UI,{logout:['Sign out','साइन आउट','साइन आउट']});
applyUi();
Promise.all([api('/me'),api('/schemes'),api('/me/documents'),api('/me/alerts'),api('/me/recommendations'),api('/me/matches')]).then(function(r){
 me=r[0];Object.assign(p,me.profile);p.mob=me.mobile;saved=!!me.profile_complete;
 S=r[1].map(toRow);vault=r[2];rem=r[3];feed=r[4];LV=r[5];om=saved;view()
}).catch(function(e){$('main').innerHTML='<div class="panel empty">'+esc(e.message)+'</div>'});
