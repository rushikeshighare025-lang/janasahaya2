/* Sign-in / create-account page. The site opens here; the app lives at /app and needs a session. */
var lang = +(function () { try { return localStorage.getItem('sahayak_lang'); } catch (e) { return 0; } })() || 0;
var mode = 'in', busy = false, err = '', v = { name: '', mobile: '' }, pref = {};
try { pref = JSON.parse(localStorage.getItem('sahayak_ui')) || {}; } catch (e) {}
var X = {
  title: ['Find every scheme you qualify for', 'हर वह योजना खोजें जिसके आप पात्र हैं', 'तुम्ही पात्र असलेली प्रत्येक योजना शोधा'],
  pts: [['Check eligibility from your profile', 'Keep your documents in one place', 'Get reminders before deadlines', 'Available in English, हिन्दी and मराठी'],
        ['अपनी प्रोफ़ाइल से पात्रता जाँचें', 'दस्तावेज़ एक जगह रखें', 'समय सीमा से पहले अलर्ट पाएँ', 'English, हिन्दी और मराठी में उपलब्ध'],
        ['प्रोफाइलवरून पात्रता तपासा', 'कागदपत्रे एका जागी ठेवा', 'मुदतीपूर्वी सूचना मिळवा', 'English, हिन्दी आणि मराठीत उपलब्ध']],
  tab: [['Sign in', 'Create account'], ['साइन इन', 'खाता बनाएँ'], ['साइन इन', 'खाते तयार करा']],
  name: ['Full name', 'पूरा नाम', 'पूर्ण नाव'], mob: ['Mobile number', 'मोबाइल नंबर', 'मोबाईल क्रमांक'],
  pw: ['Password', 'पासवर्ड', 'पासवर्ड'], hint: ['At least 8 characters', 'कम से कम 8 अक्षर', 'किमान ८ अक्षरे'],
  go: [['Sign in', 'Create account'], ['साइन इन करें', 'खाता बनाएँ'], ['साइन इन करा', 'खाते तयार करा']],
  wait: ['Please wait…', 'कृपया प्रतीक्षा करें…', 'कृपया थांबा…'],
  consent: ['By creating an account you agree that your profile and uploaded documents are stored on this server. Independent helper tool, not an official government website.',
            'खाता बनाकर आप सहमत हैं कि आपकी प्रोफ़ाइल और अपलोड किए दस्तावेज़ इस सर्वर पर रखे जाएँगे। स्वतंत्र सहायक टूल, आधिकारिक सरकारी वेबसाइट नहीं।',
            'खाते तयार करून तुम्ही मान्य करता की तुमची प्रोफाइल व अपलोड केलेली कागदपत्रे या सर्व्हरवर ठेवली जातील. स्वतंत्र सहाय्यक साधन, अधिकृत सरकारी संकेतस्थळ नाही.'],
  dark: ['Dark mode', 'डार्क मोड', 'डार्क मोड'],
  e: { invalid: ['Wrong mobile number or password', 'मोबाइल नंबर या पासवर्ड ग़लत है', 'मोबाईल क्रमांक किंवा पासवर्ड चुकीचा आहे'],
       exists: ['This mobile number is already registered', 'यह मोबाइल नंबर पहले से पंजीकृत है', 'हा मोबाईल क्रमांक आधीच नोंदणीकृत आहे'],
       limited: ['Too many attempts. Try again in 15 minutes.', 'बहुत अधिक प्रयास। 15 मिनट बाद कोशिश करें।', 'खूप प्रयत्न झाले. १५ मिनिटांनी पुन्हा प्रयत्न करा.'],
       validation: ['Enter your name, a valid 10-digit mobile number and a password of 8 or more characters', 'अपना नाम, सही 10 अंकों का मोबाइल नंबर और 8+ अक्षर का पासवर्ड दें', 'तुमचे नाव, योग्य १० अंकी मोबाईल क्रमांक व ८+ अक्षरी पासवर्ड द्या'],
       other: ['Something went wrong. Please try again.', 'कुछ गड़बड़ हुई। फिर कोशिश करें।', 'काहीतरी चुकले. पुन्हा प्रयत्न करा.'] }
};
function T(k) { return X[k][lang]; }
function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
function theme() { var t = pref.th || (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'); document.documentElement.dataset.theme = t; document.documentElement.dataset.fs = pref.fs || 'm'; return t; }
function render() {
  var th = theme(), i = mode == 'in' ? 0 : 1;
  document.documentElement.lang = ['en', 'hi', 'mr'][lang];
  document.title = 'JanSahayak – ' + T('tab')[i];
  document.getElementById('note').textContent = T('consent');
  document.getElementById('util').innerHTML = '<div class="g"><span>🌙 ' + T('dark') + '</span><button class="sw" data-th="1" role="switch" aria-checked="' + (th == 'dark') + '" aria-label="' + T('dark') + '"><i></i></button></div><div class="g">' +
    ['English', 'हिन्दी', 'मराठी'].map(function (n, j) { return '<button class="u" data-l="' + j + '" aria-pressed="' + (lang == j) + '">' + n + '</button>'; }).join('') + '</div>';
  document.getElementById('root').innerHTML =
    '<section class="hero authhero"><div class="logo big" aria-hidden="true">☸</div><h1>JanSahayak · जनसहायक</h1><h2>' + T('title') + '</h2><ul>' + T('pts').map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ul></section>' +
    '<section class="panel authcard"><div class="tabs" role="tablist">' + T('tab').map(function (x, j) { return '<button role="tab" aria-selected="' + (j == i) + '" data-m="' + (j ? 'up' : 'in') + '">' + x + '</button>'; }).join('') + '</div>' +
    '<form id="f" novalidate>' +
    (i ? '<div class="fld"><label for="name">' + T('name') + '</label><input id="name" type="text" autocomplete="name" maxlength="100" value="' + esc(v.name) + '"></div>' : '') +
    '<div class="fld"><label for="mobile">' + T('mob') + '</label><input id="mobile" type="tel" inputmode="numeric" autocomplete="username" maxlength="10" value="' + esc(v.mobile) + '"></div>' +
    '<div class="fld"><label for="pw">' + T('pw') + '</label><input id="pw" type="password" autocomplete="' + (i ? 'new-password' : 'current-password') + '" maxlength="72">' + (i ? '<small>' + T('hint') + '</small>' : '') + '</div>' +
    '<div id="err" class="msg b" role="alert"' + (err ? '' : ' hidden') + '>' + esc(err) + '</div>' +
    '<button class="primary" type="submit"' + (busy ? ' disabled' : '') + '>' + (busy ? T('wait') : T('go')[i]) + '</button></form></section>';
}
document.addEventListener('click', function (e) {
  var b = e.target.closest('button'); if (!b) return; var d = b.dataset;
  if (d.l) { lang = +d.l; try { localStorage.setItem('sahayak_lang', lang); } catch (x) {} }
  else if (d.th) { pref.th = theme() == 'dark' ? 'light' : 'dark'; try { localStorage.setItem('sahayak_ui', JSON.stringify(pref)); } catch (x) {} }
  else if (d.m) { mode = d.m; err = ''; }
  else return;
  render();
});
document.addEventListener('input', function (e) { if (e.target.id == 'name') v.name = e.target.value; if (e.target.id == 'mobile') v.mobile = e.target.value; });
document.addEventListener('submit', function (e) {
  e.preventDefault(); if (busy) return;
  var up = mode == 'up', body = { mobile: v.mobile.trim(), password: document.getElementById('pw').value };
  if (up) body.name = v.name.trim();
  busy = true; err = ''; render();
  api(up ? '/auth/register' : '/auth/login', { method: 'POST', body: body })
    .then(function () { location.href = '/app'; })
    .catch(function (x) { busy = false; err = (X.e[x.code] || X.e.other)[lang]; render(); document.getElementById('err').focus && document.getElementById('pw').focus(); });
});
render();
